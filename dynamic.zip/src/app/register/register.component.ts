import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,Validators,FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  Formdata:any;
  registrationdone = false;
  allUsers:any;
  user:any={};
  myUser:any={};
  password ='';
  confirmPassword='';
  
  constructor(private router:Router,private fb:FormBuilder) { }

  ngOnInit(): void {

 
    // this.Formdata=new FormGroup(
    //   {
    //     // Name:new FormControl("",Validators.required),
    //     //  email: new FormControl("", Validators.compose([Validators.required, Validators.email])),
    //     //  Password: new FormControl("", Validators.required),
    //     // repass:new FormControl("",Validators.required),
    //     // Age:new FormControl("",Validators.required),
    //     // number:new FormControl("",Validators.required)
        
    //  }
    // )
    this.createRegistrationForm();
    this.getUser();  
  }
    createRegistrationForm(){
      this.Formdata = this.fb.group({
        Name:["",Validators.required],
        email:  ["", Validators.compose([Validators.required, Validators.email])],
        Password:["", Validators.compose([Validators.required,Validators.minLength(6)])],
       repass:["",Validators.compose([Validators.required,Validators.minLength(6)],)],
       number:["", Validators.compose([Validators.required, Validators.pattern(/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/)])],
       Age:["", Validators.compose([Validators.required,Validators.pattern('^(0?[1-9]|[1-9][0-9]|[1][1-9][1-9]|120)$')])],
       passwordMatchValidator:[Validators.required]
      })
    }
  
     passwordMatchValidator(Formdata: FormGroup) {
      return this.Formdata.get('Password').value === this.Formdata.get('repass').value
   }

  submit(){
    // console.log("==Formdata",this.Formdata.value)
    //       let user = {email:Formdata.email, Password:Formdata.Password};

    // this.Formdata.value = this.Formdata.email
    // this.Formdata.value = this.Formdata.password
    // let data = localStorage.setItem("user",JSON.stringify(user))
    // console.log("==dataaa",data)

    
    // if(Formdata.email=='email' && Formdata.password=='password'){
    //   let user = {email:Formdata.email, password:Formdata.password};
    //   let data = localStorage.setItem("user", JSON.stringify(user));
    //   console.log("===data",data)
    //   //  this.router.navigate(['/']);
    // } 
    //   else{
    // window.location.href = "/register";
    
    //   }
    // this.router.navigate(['/list'])
     
    

    
       this.user=Object.assign(this.user,this.Formdata.value);
       this.adduser(this.user);
       this.getUser();
       this.Formdata.reset();

  }
  adduser(user:any){
    let users=[];
    if(localStorage.getItem('Users')){
  
      users=JSON.parse(localStorage.getItem('Users') || '[]');
      users=[...users,user];
    }
    else{
      users=[user];
    }
    localStorage.setItem('Users',JSON.stringify(users));
  
    
  }
  getUser(){
      
    this.allUsers=JSON.parse(localStorage.getItem('Users') || '[]');
        console.log(this.allUsers);
  }



}

