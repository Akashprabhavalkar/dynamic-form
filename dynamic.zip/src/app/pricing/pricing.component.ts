import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-pricing',
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.css']
})
export class PricingComponent implements OnInit {

  name = 'This is XLSX TO JSON CONVERTER';


  // fileUrl: any;
  // arrayBuffer: any;
  // file: any = File;
  // JSONObject = {
  //   object: {},
  //   string: ''
  // };


  // incomingfile(event: any) {
  //   this.file = event.target.files[0];
  // }

  // constructor(private sanitizer: DomSanitizer) { }

  // upload() {
  //   const fileReader = new FileReader();
  //   fileReader.onload = (e) => {
  //     this.arrayBuffer = fileReader.result;
  //     let data = new Uint8Array(this.arrayBuffer);
  //     const arr = new Array();
  //     for (let i = 0; i !== data.length; ++i) { arr[i] = String.fromCharCode(data[i]); }
  //     const bstr = arr.join('');
  //     const workbook = XLSX.read(bstr, { type: 'binary' });
  //     const first_sheet_name = workbook.SheetNames[0];
  //     const worksheet = workbook.Sheets[first_sheet_name];
  //     const JSON_Object = XLSX.utils.sheet_to_json(worksheet, { raw: true });

  //     this.JSONObject.object = JSON_Object; //Data in JSON Format
  //     this.JSONObject.string = JSON.stringify(JSON_Object); //Data in String Format

  //     console.log('JSON object:', this.JSONObject.object);
  //   };
  //   fileReader.readAsArrayBuffer(this.file);
  //   let data = this.arrayBuffer

  //   const blob = new Blob([data], { type: 'application/octet-stream' });

  //   this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
  // }

  onFileChange(ev:any) {
    let workBook:any = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial:any, name:any) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      const dataString = JSON.stringify(jsonData);
    //  <HTMLElement>document.getElementById('output').innerHTML = dataString.slice(0, 300).concat("...");
      this.setDownload(dataString);
    }
    reader.readAsBinaryString(file);
  }


  setDownload(data:any) {
  
    setTimeout(() => {
      const el =<HTMLElement>document.querySelector("#download");
      el.setAttribute("href", `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
      el.setAttribute("download", 'xlsxtojson.json');
    }, 1000)
  }

  ngOnInit(): void {
  }

}
// let data = JsonToXML.parse("person", this.obj)
//     console.log("data", data);
//     const blob = new Blob([data], { type: 'application/octet-stream' });

//     this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));

