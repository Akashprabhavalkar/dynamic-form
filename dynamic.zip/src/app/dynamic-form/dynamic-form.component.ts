import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder,Validators } from '@angular/forms'

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css']
})
export class DynamicFormComponent implements OnInit {
Formdata:any;

  title = 'Nested FormArray Example Add Form Fields Dynamically';
 
  empForm:FormGroup;
  formsubmit=false;
  constructor(private fb:FormBuilder) {
    this.empForm=this.fb.group({
      employees: this.fb.array([]) ,
    })
   }

   employees(): FormArray {
    return this.empForm.get("employees") as FormArray
  }

  newEmployee(): FormGroup {
    return this.fb.group({
      firstName: ["",Validators.required],
      lastName: ['',Validators.required],
      email:  ["", Validators.compose([Validators.required, Validators.email])],
      mobile:["", Validators.compose([Validators.required, Validators.pattern(/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/)])],
      


      // skills:this.fb.array([])
    })

    
  }

  addEmployee() {                                     //[ 11] array.len >1 ? rmov :""
    this.formsubmit=true;
    console.log("Adding a employee");
    this.employees().push(this.newEmployee());
  }

  removeEmployee(empIndex:number) {
  
    this.employees().removeAt(empIndex=1);  
  
       //if(employee.length>1){empIndex}
  }

  onSubmit() {
    console.log(this.empForm.value);
  }

  ngOnInit(): void {
  }

}
