import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { FaqsComponent } from './faqs/faqs.component';
import { FeaturesComponent } from './features/features.component';
import { LoginComponent } from './login/login.component';
import { PricingComponent } from './pricing/pricing.component';
import { RegisterComponent } from './register/register.component';
import { UserListComponent } from './user-list/user-list.component';

const routes: Routes = [
  {path:"",component:LoginComponent},
  {path:"user-list",component:UserListComponent},
  {path:"register",component:RegisterComponent},
  {path:"features",component:FeaturesComponent},
  {path:"pricing",component:PricingComponent},
  {path:"faqs",component:FaqsComponent},
  {path:"about",component:AboutComponent},
  {path:"dynamic",component:DynamicFormComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
